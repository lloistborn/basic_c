#include "mylib.c"

int main(int argc, char const *argv[])
{
	int num;
	char *chr;

	scanf("%d", &num);

	myItoa(chr, num);
	
	// printf("%s\n", chr);

	return 0;
}